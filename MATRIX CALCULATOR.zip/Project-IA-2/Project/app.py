from flask import Flask, request, render_template
import numpy as np
import sqlite3
import datetime

app = Flask(__name__)

# Function to connect to the SQLite database
def connect_database():
    try:
        connection = sqlite3.connect('matrix_calculations11.db')
        cursor = connection.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS calculations (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            operation TEXT,
                            result TEXT,
                            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                        )''')
        connection.commit()
        return connection, cursor
    except sqlite3.Error as error:
        print("Error:", error)

# Function to add a calculation to the database
def add_calculation(operation, result):
    connection, cursor = connect_database()
    try:
        timestamp = datetime.datetime.now().replace(microsecond=0)
        cursor.execute("INSERT INTO calculations (operation, result, timestamp) VALUES (?, ?, ?)",
                       (operation, str(result), timestamp))
        connection.commit()
        print("Calculation added successfully.")
    except sqlite3.Error as error:
        print("Error:", error)
    finally:
        connection.close()

# Function to retrieve previous calculations from the database
def get_previous_results():
    connection, cursor = connect_database()
    try:
        cursor.execute("SELECT operation, result, timestamp FROM calculations")
        calculations = cursor.fetchall()
        return calculations
    except sqlite3.Error as error:
        print("Error:", error)
    finally:
        connection.close()


# Parse matrix utility function
# Parse matrix utility function
def parse_matrix(rows, cols, form, key_prefix='matrix'):
    matrix = []
    for i in range(rows):
        row = [float(form.get(f'{key_prefix}_{i+1}_{j+1}', 0.0)) for j in range(cols)]
        matrix.append(row)
    return np.array(matrix)






@app.route('/eigen', methods=['POST'])
def compute_eigen():
    rows = int(request.form['rows'])
    cols = int(request.form['cols'])
    if rows != cols:
        return "The matrix must be square to find eigenvalues and eigenvectors.", 400
    matrix = parse_matrix(rows, cols, request.form, 'matrix1')
    eigenvalues, eigenvectors = np.linalg.eig(matrix)
    # Assuming you have a function to add the calculation to the database
    add_calculation('Eigenvalues and Eigenvectors', (eigenvalues, eigenvectors))
    return render_template('result.html', operation='Eigenvalues and Eigenvectors', eigenvalues=eigenvalues, eigenvectors=eigenvectors)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add', methods=['POST'])
def add_matrices():
    rows = int(request.form['rows'])
    cols = int(request.form['cols'])
    matrix1 = parse_matrix(rows, cols, request.form, 'matrix1')
    matrix2 = parse_matrix(rows, cols, request.form, 'matrix2')
    result = matrix1 + matrix2
    add_calculation('Addition', result)
    return render_template('result.html', operation='Addition', result=result)

@app.route('/subtract', methods=['POST'])
def subtract_matrices():
    rows = int(request.form['rows'])
    cols = int(request.form['cols'])
    matrix1 = parse_matrix(rows, cols, request.form, 'matrix1')
    matrix2 = parse_matrix(rows, cols, request.form, 'matrix2')
    result = matrix1 - matrix2
    add_calculation('Subtraction', result)
    return render_template('result.html', operation='Subtraction', result=result)

@app.route('/multiply', methods=['POST'])
def multiply_matrices_route():
    rows1 = int(request.form['rows1'])
    cols1 = int(request.form['cols1'])
    rows2 = int(request.form['rows2'])
    cols2 = int(request.form['cols2'])
    if cols1 != rows2:
        return "Matrix dimensions are incompatible for multiplication", 400
    matrix1 = parse_matrix(rows1, cols1, request.form, 'matrix1')
    matrix2 = parse_matrix(rows2, cols2, request.form, 'matrix2')
    result = np.dot(matrix1, matrix2)
    add_calculation('Multiplication', result.tolist())
    return render_template('result.html', operation='Multiplication', result=result)



@app.route('/previous')
def previous_calculations():
    calculations = get_previous_results()
    return render_template('previous.html', calculations=calculations)


@app.route('/delete/<int:calculation_id>', methods=['POST'])
def delete_calculation(calculation_id):
    connection, cursor = connect_database()
    try:
        cursor.execute("DELETE FROM calculations WHERE id=?", (calculation_id,))
        connection.commit()
        return '', 204  # No content response, indicating successful deletion
    except sqlite3.Error as error:
        print("Error:", error)
        return 'Failed to delete calculation', 500  # Internal server error
    finally:
        connection.close()

if __name__ == '__main__':
    app.run(debug=False, port=5008)
